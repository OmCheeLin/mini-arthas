package com.omcheelin.bootdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.nio.ByteBuffer;

@SpringBootApplication
public class BootDemoApplication {

    public static void main(String[] args) {
        ByteBuffer byteBuffer = ByteBuffer.allocateDirect(1024 * 1024 * 1024);
        System.out.println("Main running...");
        byte b = byteBuffer.get();
        SpringApplication.run(BootDemoApplication.class, args);
    }

}
